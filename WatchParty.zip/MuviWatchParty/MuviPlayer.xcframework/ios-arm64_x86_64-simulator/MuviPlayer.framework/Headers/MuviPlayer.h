//
//  MuviPlayer.h
//  MuviPlayer
//
//  Created by Muvi on 16/12/19.
//  Copyright © 2019 MUVI. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MuviPlayer.
FOUNDATION_EXPORT double MuviPlayerVersionNumber;

//! Project version string for MuviPlayer.
FOUNDATION_EXPORT const unsigned char MuviPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MuviPlayer/PublicHeader.h>


